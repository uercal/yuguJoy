<?php

namespace app\common\model;

/**
 * 商品规格模型
 * Class GoodsSpec
 * @package app\common\model
 */
class GoodsSpec extends BaseModel
{
    protected $name = 'goods_spec';

}
