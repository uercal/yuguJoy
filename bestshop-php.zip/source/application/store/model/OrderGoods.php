<?php

namespace app\store\model;

use app\common\model\OrderGoods as OrderGoodsModel;

/**
 * 订单商品模型
 * Class OrderGoods
 * @package app\store\model
 */
class OrderGoods extends OrderGoodsModel
{

}
